//
// Prints 'Hello World' from rank 0 and 
// prints what process it is out of the total number of processes
//

#include <stdio.h>
#include <stdlib.h>

#include <mpi.h>

int main(void)
{
  int rank, size, ierr;
  MPI_Comm comm;

  comm  = MPI_COMM_WORLD;

  MPI_Init(NULL,NULL);
  MPI_Comm_rank(comm, &rank);            
  MPI_Comm_size(comm, &size); 

  // Only processor 0 prints 
  if(rank == 0)
    {
      printf("Hello World!\n"); 
    }

  // Each process prints out its rank
  printf("I am rank %d out of %d\n", rank, size);

  MPI_Finalize();

  return 0;
}
